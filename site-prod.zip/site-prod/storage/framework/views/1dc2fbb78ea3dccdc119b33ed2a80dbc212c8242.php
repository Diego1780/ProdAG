<div>
    <form action="" class="form-inline my-2 my-lg-0" type="get" action="<?php echo e(url('/')); ?>" > 
            <input class="form-control mr-sm-2" wire:model="searchTerm" type="text" placeholder="Recherchez">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <a href="<?php echo e(URL::to('/'.$user->slug)); ?>" style="color:black;" >
                        <ul>
                            <li>
                            <?php echo e($user->title); ?>

                            </li>
                        </ul>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="#"><i class="fa fa-search" style="color: rgba(123,123,123,0.5);"></i></a></li>

    </form>         
</div><?php /**PATH /Users/yanis/Downloads/ag-prod/projet/site-prod/resources/views/livewire/search.blade.php ENDPATH**/ ?>