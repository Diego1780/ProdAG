<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>pag-site</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css">
    <link rel="stylesheet" href="https://unpkg.com/@bootstrapstudio/bootstrap-better-nav/dist/bootstrap-better-nav.min.css">
    <link rel="stylesheet" href="/css/styles.min.css">
    <script src="<?php echo e(asset('js/scroll.js')); ?>"></script>
</head>

<body>
<?php echo \Livewire\Livewire::styles(); ?> 
    <header id="header">
        <nav class="navbar navbar-light navbar-expand-md" style="background-color: #ffffff;">
            <div class="container-fluid"><a class="navbar-brand" href="<?php echo e(url('/accueil')); ?>"><img src="/img/LOGO.png" width="200px"></a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div
                    class="collapse navbar-collapse d-md-flex justify-content-md-end" id="navcol-1">
                    <ul class="nav navbar-nav">
                        <li class="nav-item" role="presentation"><a class="nav-link active" href="#" style="color: #000000;"></a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(url('/a-propos')); ?>" style="color: rgba(123,123,123,0.5);">A propos</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="<?php echo e(url('/contact')); ?>" style="color: rgba(123,123,123,0.5);">Contact</a></li>
                        
                        
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search')->html();
} elseif ($_instance->childHasBeenRendered('PmToD8l')) {
    $componentId = $_instance->getRenderedChildComponentId('PmToD8l');
    $componentTag = $_instance->getRenderedChildComponentTagName('PmToD8l');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PmToD8l');
} else {
    $response = \Livewire\Livewire::mount('search');
    $html = $response->html();
    $_instance->logRenderedChild('PmToD8l', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </ul>
                    
            </div>
            </div>
        </nav>
    </header>
    <section id="banner">
        <div style="background-color: #ffcc01;height: 86VH;">
            <h2 id="heading-banner" style="color: #000;">bienvenue</h2>
            <div id='scroll_down' >
                 <a href="#" style="color: rgb(0,0,0);"><i class="icon-arrow-down"></i></a>
            </div>
        </div>
    </section>
    <section class="text-left d-flex justify-content-around" id="work-one">
        <div id="work-left">
            <a href="<?php echo e(url('/article-1')); ?>">
            <div class="card-work">
                <div style="height: 500px;width: 600px;background-color: #ffcc01;margin-top: 35px;"></div>
                <h1 style="font-size: 20px;color:black;">Heading</h1>
            </div>
            </a>
        </div>
        <div id="work-right">
        <a href="<?php echo e(url('/article-2')); ?>">
            <div class="card-work">
                <div style="height: 200px;width: 315px;background-color: #ffcc01;margin-top: 35px;"></div>
                <h1 style="font-size: 20px;color:black;">Heading</h1>
            </div>
            </a>
            <a href="<?php echo e(url('/article-3')); ?>">
            <div class="card-work">
                <div style="height: 200px;width: 315px;background-color: #ffcc01;margin-top: 35px;"></div>
                <h1 style="font-size: 20px;color:black;">Heading</h1>
            </div>
            </a>
            <a href="<?php echo e(url('/article-4')); ?>">
            <div class="card-work">
                <div style="height: 200px;width: 315px;background-color: #ffcc01;margin-top: 35px;"></div>
                <h1 style="font-size: 20px;color:black;">Heading</h1>
            </a>
            </div>
            <a href="<?php echo e(url('/article-4')); ?>">
            <div class="card-work">
            
                <div style="height: 200px;width: 315px;background-color: #ffcc01;margin-top: 35px;"></div>
                <h1 style="font-size: 20px;color:black;">Heading</h1>
            </a>
            
                
        </div>
        </div>

       

    </section>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.2.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/@bootstrapstudio/bootstrap-better-nav/dist/bootstrap-better-nav.min.js"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

 </body>
</html><?php /**PATH /Users/yanis/Downloads/ag-prod/projet/site-prod/resources/views/visuel/accueil.blade.php ENDPATH**/ ?>