<?php return array (
  'frontpage' => 'App\\Http\\Livewire\\Frontpage',
  'pages' => 'App\\Http\\Livewire\\Pages',
  'search' => 'App\\Http\\Livewire\\Search',
);