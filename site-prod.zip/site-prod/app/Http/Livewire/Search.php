<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Page;
use Livewire\WithPagination;

class Search extends Component
{
    use WithPagination;
    public $searchTerm;

    public function render()
    {
        $searchTerm = '%'.$this->searchTerm.'%';
        return view('livewire.search',[
            'users' => Page::where('title','like', $searchTerm)->paginate(10)
        ]);
    }
    public function getSlug($slug)
    {
        $page = Page::where('slug', $slug)->firstOrFail();
        return $page;
    }
}
