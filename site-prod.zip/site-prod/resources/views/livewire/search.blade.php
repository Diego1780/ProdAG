<div>
    <form action="" class="form-inline my-2 my-lg-0" type="get" action="{{ url('/') }}" > 
            <input class="form-control mr-sm-2" wire:model="searchTerm" type="text" placeholder="Recherchez">
                @foreach($users as $user)

                    <a href="{{  URL::to('/'.$user->slug)}}" style="color:black;" >
                        <ul>
                            <li>
                            {{ $user->title }}
                            </li>
                        </ul>
                    </a>
                @endforeach
                        <li class="nav-item" role="presentation"><a class="nav-link" href="#"><i class="fa fa-search" style="color: rgba(123,123,123,0.5);"></i></a></li>

    </form>         
</div>