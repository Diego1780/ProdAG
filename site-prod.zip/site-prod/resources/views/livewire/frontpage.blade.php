
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>pag-site</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css">
    <link rel="stylesheet" href="https://unpkg.com/@bootstrapstudio/bootstrap-better-nav/dist/bootstrap-better-nav.min.css">
    <link rel="stylesheet" href="/css/styles.min.css">
   


<body>
    <header id="header">
        <nav class="navbar navbar-light navbar-expand-md" style="background-color: #ffffff;">
            <div class="container-fluid"><a class="navbar-brand" href="{{ url('/accueil') }}"><img src="/img/LOGO.png" width="200px"></a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div
                    class="collapse navbar-collapse d-md-flex justify-content-md-end" id="navcol-1">
                    <ul class="nav navbar-nav">
                        <li class="nav-item" role="presentation"><a class="nav-link active" href="#" style="color: #000000;">Work</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{ url('/a-propos') }}" style="color: rgba(123,123,123,0.5);">A propos</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{ url('/contact') }}" style="color: rgba(123,123,123,0.5);">Contact</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="#"><i class="fa fa-search" style="color: rgba(123,123,123,0.5);"></i></a></li>
                    </ul>
                </div>
            </div>
            
        </nav>
    </header>

    </head>
</body>
<section >
    <div id="article">
        <div class="container" style=" margin: 20px 70px 70px;">
            <div class=" card">
                        <!-- img class="h-50 card-img-top" src='img/moto.png' alt="Card image cap" style="max-width: 30rem;"-->
    
                <h5 class="card-title">{{ $title }}</h5>
       
                <div class="text-align: center">
                    <p class="card-text"  ;" >{!! $content !!}</p>
                </div>
                    <a href="#" style="color: rgb(0,0,0);"><i id='icon' class="fa fa-angle-double-up" style="font-size:36px"></i></a>

            </div>    
        </div>
    </div>
    
</section>    

