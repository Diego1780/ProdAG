<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>pag-site</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.2.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.4.1/css/simple-line-icons.min.css">
    <link rel="stylesheet" href="https://unpkg.com/@bootstrapstudio/bootstrap-better-nav/dist/bootstrap-better-nav.min.css">
    <link rel="stylesheet" href="/css/styles.min.css">
</head>

<body>
    <header id="header">
        <nav class="navbar navbar-light navbar-expand-md" style="background-color: #ffffff;">
            <div class="container-fluid"><a class="navbar-brand" href="{{ url('/accueil') }}"><img src="/img/LOGO.png" width="200px"></a><button class="navbar-toggler" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div
                    class="collapse navbar-collapse d-md-flex justify-content-md-end" id="navcol-1">
                    <ul class="nav navbar-nav">
                        <li class="nav-item" role="presentation"><a class="nav-link active" href="#" style="color: #000000;">Work</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{ url('/a-propos') }}" style="color: rgba(123,123,123,0.5);">A propos</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="{{ url('/contact') }}" style="color: rgba(123,123,123,0.5);">Contact</a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link" href="#"><i class="fa fa-search" style="color: rgba(123,123,123,0.5);"></i></a></li>
                    </ul>
            </div>
            </div>
        </nav>
    </header>

<section style="padding-top:100px;">

    <div class="container">
        <div class="row">
            <div class='col-md-6 offset-md-3' >
                <div class="card border-warning mb-3">
                    <div class="card-header border-warning mb-3">
                        Contactez-nous
                    </div>
                    <div class="card-body border-warning mb-3">
                    @if(Session::has('message_sent'))
                        <div class="alert alert-success" role="alert">
                            {{ Session::get('message_sent')}}
                        </div>
                    @endif
                        <form method="POST" action="{{route('contact.send') }}" enctype="multipart/form-data">
                        @csrf
                            <div class="form-group">
                                
                                <label for="name">Nom</label>
                                <input type="text" name="name" class="form-control">
                            </div>
                            <div class="form-group">
                                
                                <label for="surname">Prénom</label>
                                <input type="text" name="surname" class="form-control">
                            </div>
                            <div class="form-group">
                                
                                <label for="email">Email</label>
                                <input type="text" name="email" class="form-control">
                            </div>
                            <div class="form-group">
                                
                                <label for="phone">Numéro de téléphone</label>
                                <input type="text" name="phone" class="form-control">
                            </div>
                            <div class="form-group">
                                
                                <label for="msg">Message</label>
                                <textarea name="msg" class="form-control" cols="30" rows="10"></textarea>
                            
                            </div>
                            <button type="submit" class="btn btn-primary float-right">
                                Envoyer
                            </button>
                            </form>
                    </div>
                </div>
        
            </div>        
        </div>

    </div>


</section>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script> 
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
</body>